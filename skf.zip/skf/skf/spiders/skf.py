from scrapy import Request
from scrapy.spiders import CrawlSpider, Rule
from scrapy.linkextractors import LinkExtractor

from ..items import SkfItem

import json
import re

class SKFSpider(CrawlSpider):

    name = "skf"

    start_urls = ['https://www.skf.com/cn/en/our-company/find-a-distributor/by-list/index.html?widgetType=Contact%20filter%20-%20SKF%20Distributors&country=1042&second-region=&state=&city=&zip=&itmPerPage=5000&selPage=1']

    main_link = "https://www.skf.com/cn/en/our-company/find-a-distributor/by-list/index.html?widgetType=Contact%20filter%20-%20SKF%20Distributors&country=swap_country_code&second-region=&state=&city=&zip=&itmPerPage=5000&selPage=1"


    def __init__(self, *args, **kwargs):                    
        super(SKFSpider, self).__init__(*args, **kwargs)
        pass              
  

    def parse(self,response):

        codes = response.css("#country option::attr(value)").extract()
        names = response.css("#country option::text").extract()
        
        
        for code,name in zip(codes[1:],names[1:]):
            temp = self.main_link
            temp = temp.replace("swap_country_code",str(code))

            yield Request(url = temp,meta={"country":name},callback=self.page)
        

    def page(self, response):

        for data in response.css('.contact-list > ul li'):

            product = SkfItem()

            product["country"] = response.meta["country"]

            product["company"]  = data.css("h3::text").extract_first()
            product["address"] = data.css(".address::text").extract_first()

            try:
                product["address"] = product["address"].replace("\r","")
                product["address"] = product["address"].replace("\n","") 
                product["address"] = product["address"].replace("\t","") 
            except:
                pass

            for info in data.css(".row.clearfix"):
                left = info.css(".row.clearfix .left span::text").extract_first()
                right = info.css(".row.clearfix .right p::text").extract_first()

                if left == "Fax:":
                    product['fax'] = right
                    break

            product['phone'] = []
            for info in data.css(".row.clearfix"):
                left = info.css(".row.clearfix .left span::text").extract_first()
                right = info.css(".row.clearfix .right p::text").extract_first()

                if left == "Phone:":
                    try:
                        right = right.replace("\r","")
                        right = right.replace("\n","") 
                        right = right.replace("\t","") 
                    except:
                        pass
                    product['phone'].append(right)


            for info in data.css(".row.clearfix"):
                left = info.css(".row.clearfix .left span::text").extract_first()
                right = info.css(".row.clearfix .right a::text").extract_first()

                if right and "@" in right:
                    
                    try:
                        right = right.replace("\r","")
                        right = right.replace("\n","") 
                        right = right.replace("\t","") 
                    except:
                        pass
                    
                    product['email'] = right

            for info in data.css(".row.clearfix"):
                left = info.css(".row.clearfix .left span::text").extract_first()
                right = info.css(".row.clearfix .right p::text").extract()

                right = "".join(right)

                if left == "Product category:":
                    
                    try:
                        right = right.replace("\r","")
                        right = right.replace("\n","") 
                        right = right.replace("\t","") 
                    except:
                        pass
                    
                    product['product_category'] = right

            for info in data.css(".row.clearfix"):
                left = info.css(".row.clearfix .left span::text").extract_first()
                right = info.css(".row.clearfix .right p::text").extract()

                right = "".join(right)

                if left == "Distributor contact":
                    
                    try:
                        right = right.replace("\r","")
                        right = right.replace("\n","") 
                        right = right.replace("\t","") 
                    except:
                        pass
                    
                    product['Distributor_contact'] = right

            product["website"] = data.css(".website::attr(href)").extract_first()

            yield product

